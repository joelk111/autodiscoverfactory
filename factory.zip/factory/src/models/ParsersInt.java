package models;

public interface ParsersInt {
	
	
	public  String parse(String data);

}
